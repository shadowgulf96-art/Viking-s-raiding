/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Anchor, 
  Sword, 
  Home, 
  Shield, 
  Wind, 
  Coins, 
  Ship, 
  Skull, 
  TrendingUp, 
  History,
  AlertTriangle,
  ChevronRight,
  RefreshCw,
  Trophy
} from 'lucide-react';

// --- Constants & Types ---

const MAX_TURNS = 12;

interface Village {
  id: number;
  name: string;
  difficulty: number;
  treasure: number;
  raided: boolean;
}

interface Player {
  name: string;
  shipPosition: number; // 0 is base, 1-5 are villages
  loot: number;
  bank: number;
  skipTurn: boolean;
}

interface GameEvent {
  type: 'storm' | 'defense' | 'big_treasure' | 'calm_sea' | 'nothing';
  message: string;
  icon: React.ReactNode;
}

const EVENTS: GameEvent[] = [
  { type: 'storm', message: "Storm! You lose your next turn.", icon: <Wind className="text-blue-400" /> },
  { type: 'defense', message: "Defense rises! Next raid is harder.", icon: <Shield className="text-red-400" /> },
  { type: 'big_treasure', message: "Big Treasure! Gain +2 loot instantly.", icon: <Coins className="text-yellow-400" /> },
  { type: 'calm_sea', message: "Calm Sea! Move +1 extra space now.", icon: <TrendingUp className="text-green-400" /> },
  { type: 'nothing', message: "Quiet waters... nothing happens.", icon: <Anchor className="text-gray-400" /> },
];

const INITIAL_VILLAGES: Village[] = [
  { id: 1, name: "Small Fishing Village", difficulty: 3, treasure: 2, raided: false },
  { id: 2, name: "Monastery", difficulty: 4, treasure: 3, raided: false },
  { id: 3, name: "Market Town", difficulty: 5, treasure: 4, raided: false },
  { id: 4, name: "Fortified Harbor", difficulty: 6, treasure: 5, raided: false },
  { id: 5, name: "Rich King's Port", difficulty: 7, treasure: 6, raided: false },
];

// --- Components ---

export default function App() {
  const [gameState, setGameState] = useState<'intro' | 'playing' | 'gameOver'>('intro');
  const [turn, setTurn] = useState(1);
  const [player, setPlayer] = useState<Player>({
    name: 'Ragnar',
    shipPosition: 0,
    loot: 0,
    bank: 0,
    skipTurn: false,
  });
  const [villages, setVillages] = useState<Village[]>(INITIAL_VILLAGES);
  const [logs, setLogs] = useState<string[]>(["Welcome to the Viking Raid!"]);
  const [currentEvent, setCurrentEvent] = useState<GameEvent | null>(null);
  const [extraDifficulty, setExtraDifficulty] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  const addLog = (msg: string) => {
    setLogs(prev => [msg, ...prev].slice(0, 50));
  };

  const startGame = (name: string) => {
    setPlayer({
      name: name || 'Ragnar',
      shipPosition: 0,
      loot: 0,
      bank: 0,
      skipTurn: false,
    });
    setVillages(INITIAL_VILLAGES);
    setTurn(1);
    setLogs(["The campaign begins!"]);
    setGameState('playing');
    drawEvent();
  };

  const drawEvent = useCallback(() => {
    const event = EVENTS[Math.floor(Math.random() * EVENTS.length)];
    setCurrentEvent(event);
    setExtraDifficulty(0);

    if (event.type === 'storm') {
      setPlayer(p => ({ ...p, skipTurn: true }));
    } else if (event.type === 'defense') {
      setExtraDifficulty(1);
    } else if (event.type === 'big_treasure') {
      setPlayer(p => ({ ...p, loot: p.loot + 2 }));
    } else if (event.type === 'calm_sea') {
      setPlayer(p => ({ ...p, shipPosition: Math.min(p.shipPosition + 1, 5) }));
    }
    
    addLog(`[Event] ${event.message}`);
  }, []);

  const nextTurn = () => {
    if (turn >= MAX_TURNS || villages.every(v => v.raided)) {
      endGame();
      return;
    }

    setTurn(t => t + 1);
    drawEvent();
  };

  const endGame = () => {
    setPlayer(p => {
      const finalBank = p.bank + p.loot;
      return { ...p, bank: finalBank, loot: 0 };
    });
    setGameState('gameOver');
  };

  const handleAction = (action: 'sail' | 'raid' | 'return', targetVillageId?: number) => {
    if (isAnimating) return;

    if (player.skipTurn) {
      addLog(`${player.name} loses this turn because of the storm.`);
      setPlayer(p => ({ ...p, skipTurn: false }));
      nextTurn();
      return;
    }

    switch (action) {
      case 'sail':
        if (targetVillageId !== undefined) {
          setPlayer(p => ({ ...p, shipPosition: targetVillageId }));
          addLog(`${player.name} sails to ${villages[targetVillageId - 1].name}.`);
          nextTurn();
        }
        break;

      case 'raid':
        if (player.shipPosition === 0) {
          addLog("You are at base. Sail to a village first.");
          return;
        }
        const village = villages[player.shipPosition - 1];
        if (village.raided) {
          addLog("This village has already been raided.");
          return;
        }

        setIsAnimating(true);
        setTimeout(() => {
          const roll = Math.floor(Math.random() * 6) + 1;
          const bonus = Math.floor(Math.random() * 3);
          const power = roll + bonus;
          const target = village.difficulty + extraDifficulty;

          if (power >= target) {
            setVillages(prev => prev.map(v => v.id === village.id ? { ...v, raided: true } : v));
            setPlayer(p => ({ ...p, loot: p.loot + village.treasure }));
            addLog(`Victory! Raid power ${power} vs ${target}. Gained ${village.treasure} loot.`);
          } else {
            setPlayer(p => ({ ...p, loot: Math.max(0, p.loot - 1) }));
            addLog(`Failed raid! Raid power ${power} vs ${target}. Lost 1 loot.`);
          }
          setIsAnimating(false);
          nextTurn();
        }, 600);
        break;

      case 'return':
        if (player.shipPosition === 0) {
          addLog("You are already at base.");
          return;
        }
        addLog(`${player.name} returns to base and banks ${player.loot} treasure.`);
        setPlayer(p => ({ ...p, bank: p.bank + p.loot, loot: 0, shipPosition: 0 }));
        nextTurn();
        break;
    }
  };

  const getRank = (score: number) => {
    if (score >= 15) return { title: "Legendary Viking", desc: "Songs will be sung about you." };
    if (score >= 8) return { title: "Strong Raider", desc: "Your clan is proud." };
    return { title: "Rough Season", desc: "The sea was not kind." };
  };

  if (gameState === 'intro') {
    return <IntroScreen onStart={startGame} />;
  }

  if (gameState === 'gameOver') {
    const rank = getRank(player.bank);
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-black">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="max-w-md w-full p-8 brutal-border bg-[#1a1a1e] brutal-shadow text-center"
        >
          <Trophy className="w-16 h-16 mx-auto mb-4 text-yellow-400" />
          <h1 className="text-4xl font-display uppercase mb-2">Game Over</h1>
          <p className="text-gray-400 mb-6 font-mono">Final Score: {player.bank}</p>
          
          <div className="mb-8 p-4 bg-black/50 brutal-border border-yellow-400/30">
            <h2 className="text-2xl font-display text-yellow-400 uppercase">{rank.title}</h2>
            <p className="text-sm italic text-gray-300">{rank.desc}</p>
          </div>

          <button 
            onClick={() => setGameState('intro')}
            className="w-full py-4 font-display uppercase bg-white text-black hover:bg-yellow-400 transition-colors brutal-border"
          >
            Play Again
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8 max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Header / Stats */}
      <header className="lg:col-span-12 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4">
        <div>
          <h1 className="text-4xl font-display uppercase tracking-tighter flex items-center gap-3">
            <Ship className="text-accent" /> Viking Raid
          </h1>
          <p className="text-xs font-mono text-gray-500 uppercase tracking-widest">Season Campaign • Turn {turn}/{MAX_TURNS}</p>
        </div>
        
        <div className="flex gap-4">
          <StatBox label="Loot on Ship" value={player.loot} icon={<Ship size={16} />} color="text-accent" />
          <StatBox label="Banked" value={player.bank} icon={<Home size={16} />} color="text-gold" />
          <StatBox label="Total Score" value={player.bank + player.loot} icon={<TrendingUp size={16} />} color="text-white" />
        </div>
      </header>

      {/* Main Game Area */}
      <main className="lg:col-span-8 space-y-6">
        {/* Event Card */}
        <AnimatePresence mode="wait">
          {currentEvent && (
            <motion.div 
              key={turn}
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
              className="p-4 brutal-border bg-panel brutal-shadow flex items-center gap-4 relative overflow-hidden"
            >
              <div className="p-3 bg-black/40 brutal-border border-gray-700">
                {currentEvent.icon}
              </div>
              <div>
                <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest block mb-1">Current Event</span>
                <p className="font-bold text-lg">{currentEvent.message}</p>
              </div>
              <div className="absolute right-0 top-0 h-full w-1 bg-accent/30" />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Map / Villages */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div 
            onClick={() => handleAction('return')}
            className={`p-6 brutal-border cursor-pointer transition-all ${player.shipPosition === 0 ? 'bg-accent/10 border-accent' : 'bg-panel hover:bg-panel/80'}`}
          >
            <div className="flex justify-between items-start mb-4">
              <Home className={player.shipPosition === 0 ? 'text-accent' : 'text-gray-500'} />
              {player.shipPosition === 0 && <span className="text-[10px] bg-accent px-2 py-0.5 text-white font-bold uppercase">You are here</span>}
            </div>
            <h3 className="font-display text-xl uppercase">Base Camp</h3>
            <p className="text-xs text-gray-500 font-mono mt-1">Safe harbor. Bank your loot here.</p>
          </div>

          {villages.map((v) => (
            <div 
              key={v.id}
              onClick={() => !v.raided && handleAction('sail', v.id)}
              className={`p-6 brutal-border transition-all relative overflow-hidden ${
                player.shipPosition === v.id ? 'bg-accent/10 border-accent' : 
                v.raided ? 'bg-black/40 opacity-60 grayscale' : 'bg-panel hover:bg-panel/80 cursor-pointer'
              }`}
            >
              <div className="flex justify-between items-start mb-4">
                <Anchor className={player.shipPosition === v.id ? 'text-accent' : 'text-gray-500'} />
                <div className="flex flex-col items-end">
                  {player.shipPosition === v.id && <span className="text-[10px] bg-accent px-2 py-0.5 text-white font-bold uppercase mb-1">You are here</span>}
                  {v.raided ? (
                    <span className="text-[10px] bg-gray-700 px-2 py-0.5 text-gray-300 font-bold uppercase">Raided</span>
                  ) : (
                    <span className="text-[10px] bg-gold/20 text-gold px-2 py-0.5 font-bold uppercase border border-gold/30">Open</span>
                  )}
                </div>
              </div>
              <h3 className="font-display text-xl uppercase">{v.name}</h3>
              <div className="mt-4 flex gap-4 font-mono text-[10px] uppercase tracking-wider">
                <div className="flex items-center gap-1">
                  <Shield size={12} className="text-red-400" />
                  <span>Diff: {v.difficulty}{extraDifficulty > 0 && <span className="text-red-400">+{extraDifficulty}</span>}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Coins size={12} className="text-yellow-400" />
                  <span>Treasure: {v.treasure}</span>
                </div>
              </div>
              {v.raided && <Skull className="absolute -right-4 -bottom-4 w-24 h-24 text-white/5 rotate-12" />}
            </div>
          ))}
        </div>
      </main>

      {/* Sidebar Controls & Logs */}
      <aside className="lg:col-span-4 space-y-6">
        {/* Actions */}
        <div className="p-6 brutal-border bg-panel brutal-shadow space-y-4">
          <h2 className="font-display text-2xl uppercase mb-4 flex items-center gap-2">
            <Sword className="text-accent" /> Actions
          </h2>
          
          <button 
            disabled={player.shipPosition === 0 || villages[player.shipPosition - 1]?.raided || isAnimating}
            onClick={() => handleAction('raid')}
            className={`w-full py-4 font-display uppercase flex items-center justify-center gap-2 brutal-border transition-all ${
              player.shipPosition === 0 || villages[player.shipPosition - 1]?.raided || isAnimating
              ? 'bg-gray-800 text-gray-600 cursor-not-allowed'
              : 'bg-accent text-white hover:bg-accent/90 brutal-shadow-hover'
            } ${isAnimating ? 'animate-shake' : ''}`}
          >
            {isAnimating ? <RefreshCw className="animate-spin" /> : <Skull size={20} />}
            Raid Village
          </button>

          <button 
            disabled={player.shipPosition === 0 || isAnimating}
            onClick={() => handleAction('return')}
            className={`w-full py-4 font-display uppercase flex items-center justify-center gap-2 brutal-border transition-all ${
              player.shipPosition === 0 || isAnimating
              ? 'bg-gray-800 text-gray-600 cursor-not-allowed'
              : 'bg-white text-black hover:bg-gray-200 brutal-shadow-hover'
            }`}
          >
            <Home size={20} />
            Return to Base
          </button>

          {player.skipTurn && (
            <div className="p-3 bg-blue-900/20 border border-blue-500/30 flex items-center gap-3 text-blue-400 text-xs font-mono uppercase">
              <AlertTriangle size={16} />
              <span>Turn skipped due to storm</span>
            </div>
          )}
        </div>

        {/* Logs */}
        <div className="p-6 brutal-border bg-panel brutal-shadow h-[400px] flex flex-col">
          <h2 className="font-display text-2xl uppercase mb-4 flex items-center gap-2">
            <History className="text-gray-500" /> Saga Log
          </h2>
          <div className="flex-1 overflow-y-auto space-y-2 pr-2 font-mono text-xs">
            {logs.map((log, i) => (
              <div key={i} className={`flex gap-2 ${i === 0 ? 'text-white' : 'text-gray-500'}`}>
                <ChevronRight size={14} className="shrink-0 mt-0.5" />
                <span>{log}</span>
              </div>
            ))}
          </div>
        </div>
      </aside>
    </div>
  );
}

function StatBox({ label, value, icon, color }: { label: string, value: number, icon: React.ReactNode, color: string }) {
  return (
    <div className="p-3 brutal-border bg-panel min-w-[120px]">
      <div className="flex items-center gap-2 text-[10px] font-mono text-gray-500 uppercase tracking-wider mb-1">
        {icon} {label}
      </div>
      <div className={`text-2xl font-display uppercase ${color}`}>
        {value}
      </div>
    </div>
  );
}

function IntroScreen({ onStart }: { onStart: (name: string) => void }) {
  const [name, setName] = useState('');

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-black relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <div className="absolute top-10 left-10"><Ship size={200} /></div>
        <div className="absolute bottom-10 right-10 rotate-12"><Skull size={300} /></div>
      </div>

      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="max-w-md w-full p-8 brutal-border bg-[#1a1a1e] brutal-shadow relative z-10"
      >
        <div className="text-center mb-8">
          <h1 className="text-6xl font-display uppercase tracking-tighter mb-2">Viking Raid</h1>
          <p className="text-gray-400 font-mono text-sm uppercase tracking-widest">A Strategy Saga</p>
        </div>

        <div className="space-y-6">
          <div>
            <label className="block text-[10px] font-mono text-gray-500 uppercase tracking-widest mb-2">Viking Name</label>
            <input 
              type="text" 
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Ragnar"
              className="w-full bg-black brutal-border p-4 font-display uppercase text-xl focus:outline-none focus:border-accent transition-colors"
            />
          </div>

          <div className="p-4 bg-black/50 brutal-border border-gray-800 text-xs font-mono text-gray-400 space-y-2">
            <p>• 12 Turns to loot as much as possible.</p>
            <p>• Sail to villages, then Raid them.</p>
            <p>• Return to base to bank your loot safely.</p>
            <p>• Beware of storms and rising defenses!</p>
          </div>

          <button 
            onClick={() => onStart(name)}
            className="w-full py-4 font-display uppercase bg-accent text-white hover:bg-accent/90 transition-colors brutal-border brutal-shadow-hover text-2xl"
          >
            Begin Campaign
          </button>
        </div>
      </motion.div>
    </div>
  );
}
